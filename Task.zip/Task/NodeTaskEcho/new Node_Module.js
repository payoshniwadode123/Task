const express = require('express');
const mongoose = require('mongoose');
const Book = require('./models/bookModel')
const app = express();

app.use(express.json())
app.use(express.urlencoded({extended:false}))

mongoose.set("strictQuery",false)
mongoose.connect('mongodb+srv://payoshniwadode98344:Admin123@payoshni.nrvicvh.mongodb.net/Book-Api?retryWrites=true&w=majority').then(() => {
    app.listen(3000, ()=>{
        console.log('running');
    });
    console.log('Connected to MongoDB')
}).catch((error) => {
    console.log(error);
});

app.use(express.json()); //middleware

//Routes
//Get
app.get('/book', async(req,res) => {
    try{
        const data = await Book.find({});
        res.status(200).json(data);
    }catch(error){
        res.status(500).json({message: error.message});
    }
});

app.get('/book/:id', async(req,res) => {
    try{
        const{id} =req.params;
        const data = await Book.findById(id);
        res.status(200).json(data);
    }catch(error){
        res.status(500).json({message: error.message});
    }
});

//Update the book

app.put('/book/:id', async(req,res) => {
    try{
        const{id} =req.params;
        const data = await Book.findByIdAndUpdate(id,req.body);
        if(!body){
            return res.status(404).json({message:'cannot find any book with ID ${id}'})
        }
        const UpdateBook =await Book.findById(id);
        res.status(200).json(data);
    }catch(error){
        res.status(500).json({message: error.message});
    }
});

//Delete the book

app.delete('/book/:id', async(req,res) => {
    try{
        const{id} =req.params;
        const data = await Book.findByIdAndDelete(id);
        if(!body){
            return res.status(404).json({message:'cannot find any book with ID ${id}'})
        }
        res.status(200).json(data);
    }catch(error){
        res.status(500).json({message: error.message});
    }
});

//Post 
app.post('/book', async(req,res) => {
    try{
        const data = await Book.create(req.body)
        res.status(200).json(data);
    }catch(error){
        console.log(error.message);
        res.status(500).json({message: error.message});
    }
});

app.get('/blog', (req,res) => {
    res.send('Hello Blog my my');
});




// const mongoose = require('mongoose');
// const bodyParser = require('body-parser');

// const app = express();
// app.use(bodyParser.json());

// mongoose.connect('mongodb://localhost/booksDB', {useNewUrlParser: true, useUnifiedTopology: true});

// const bookSchema = new mongoose.Schema({
//   title: String,
//   author: String,
//   genre: String,
//   publicationYear: Number,
//   ISBN: String
// });

// const Book = mongoose.model('Book', bookSchema);

// app.get('/books', (req, res) => {
//   // Retrieve list of all books
// });

// app.get('/books/:id', (req, res) => {
//   // Retrieve specific book by ID
// });

// app.post('/books', (req, res) => {
//   // Create a new book
// });

// app.put('/books/:id', (req, res) => {
//   // Update specific book by ID
// });

// app.delete('/books/:id', (req, res) => {
//   // Delete specific book by ID
// });

// app.listen(3000, () => {
//   console.log('Server is running on port 3000');
// //  functionalities. It's beyond the scope of generating code snippets".
// });