const mongoose = require('mongoose');
const { stringify } = require('querystring');

const bookSchema = mongoose.Schema(
    {
        title:{
            type: String,
            required: [true,["Please enter book title"]] 
        },
        author:{
            type: String,
            required : false
        },
        genre:{
            type: String,
            required: [true,["Please enter book genre"]] 
        },
    },
    {
        timestamps: true,
    }
);

const Book = mongoose.model('Book',bookSchema);

module.exports = Book;